<template>
    <div class="appEx">
        <h1>兑换收益</h1>
    </div>
</template>
<script>
export default {
    data(){
        return{

        }
    }
}
</script>
<style lang="less" scoped>

</style>
