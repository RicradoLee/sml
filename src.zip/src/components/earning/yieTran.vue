<template>
    <div class="appYie">
        <!-- 提取收益 -->
        <h3>提取收益</h3>
            
        <button class="ui-btn ui-btn-primary pa tr b0 l50">提取收益</button>
    </div>
</template>
<script>
export default {
    data(){
        return{

        }
    }
}
</script>
<style lang="less" scoped>

</style>
